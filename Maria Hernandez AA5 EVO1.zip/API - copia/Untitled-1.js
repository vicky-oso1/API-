const PREDEFINED_USERNAME = "user123";
const PREDEFINED_PASSWORD = "pass123";

function authenticateUser(inputData) {
  // Parse the input JSON data
  const credentials = JSON.parse(inputData);
  
  // Check if the provided credentials match the predefined ones
  if (credentials.username === PREDEFINED_USERNAME && credentials.password === PREDEFINED_PASSWORD) {
    return JSON.stringify({ message: "Authentication successful" });
  } else {
    return JSON.stringify({ message: "Authentication failed" });
  }
}

// Use BLOCK_INPUT for authentication
const result = authenticateUser(BLOCK_INPUT);
console.log(result);

