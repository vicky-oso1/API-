app.js
const express = require (" express");
const initdb = require("./config");
const modelUser = require("./model.js");
const app = express();

const router = express.router ();
//CREATE
router.post('/' ,async (req, res) => {
    const body = req.body;
    const respuesta = await modelUser.create(body)
    res.send(respuesta)
})
app.use(express.json());
app.use(router);

app.listen(3005, ()=> {
    console.log("El servidor está en el puerto 3005")
})

initdb()