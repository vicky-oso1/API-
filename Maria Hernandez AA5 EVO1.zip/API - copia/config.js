config.js
const mongoose = require('mongoose')
const dbconnect = () => {
    mongoose.set ('strictQuery', true)
    mongoose.connect("mongodb://localhost:27017/clientes")
    .then((succes) => console.log("Conexion exitosa"))
    .catch((err)=> console.log (err.message));
}
module.exports = dbconnect;