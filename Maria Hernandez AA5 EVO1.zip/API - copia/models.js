models
const mongoose = requiere('mongoose')

const userScheme = new mongoose.Schema(
    {
        name: {
            type: String,
        },
        avatar: {
            type: String,
            default: 'http://image.co'
        },
        email: {
            type: String,
            unique: true,
            required: true
        }
    }
)

const modelUser = mongoose.model('user', userScheme);
module.exports = modelUser;